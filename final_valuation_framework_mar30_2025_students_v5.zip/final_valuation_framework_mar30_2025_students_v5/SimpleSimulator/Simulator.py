import sys

class SimpleSimulator:
    def sjj(self):
        self.opcodes={
            "0110011":"add","0110011":"sub","0110011":"slt",
            "0110011":"srl","0110011":"or","0110011":"and",
            "0000011":"lw","0010011":"addi","1100111":"jalr",
            "0100011":"sw","1100011":"beq","1100011":"bne",
            "1101111":"jal","1110011":"rst","1111111":"halt"
        }
        self.registers = {
            "00000": "zero", "00001": "ra", "00010": "sp", "00011": "gp",
            "00100": "tp", "00101": "t0", "00110": "t1", "00111": "t2",
            "01000": "s0", "01001": "s1", "01010": "a0", "01011": "a1",
            "01100": "a2", "01101": "a3", "01110": "a4", "01111": "a5",
            "10000": "a6", "10001": "a7", "10010": "s2", "10011": "s3",
            "10100": "s4", "10101": "s5", "10110": "s6", "10111": "s7",
            "11000": "s8", "11001": "s9", "11010": "s10", "11011": "s11",
            "11100": "t3", "11101": "t4", "11110": "t5", "11111": "t6"
        }
        self.datamemory = {
            "10000": 0, "10004": 0, "10008": 0, "1000C": 0,
            "10010": 0, "10014": 0, "10018": 0, "1001C": 0,
            "10020": 0, "10024": 0, "10028": 0, "1002C": 0,
            "10030": 0, "10034": 0, "10038": 0, "1003C": 0,
            "10040": 0, "10044": 0, "10048": 0, "1004C": 0,
            "10050": 0, "10054": 0, "10058": 0, "1005C": 0,
            "10060": 0, "10064": 0, "10068": 0, "1006C": 0,
            "10070": 0, "10074": 0, "10078": 0, "1007C": 0
        }
        
        self.reg_value = {
        "zero": 0, "ra": 0, "sp": 380, "gp": 0,
        "tp": 0, "t0": 0, "t1": 0, "t2": 0,
        "s0": 0, "s1": 0, "a0": 0, "a1": 0,
        "a2": 0, "a3": 0, "a4": 0, "a5": 0,
        "a6": 0, "a7": 0, "s2": 0, "s3": 0,
        "s4": 0, "s5": 0, "s6": 0, "s7": 0,
        "s8": 0, "s9": 0, "s10": 0, "s11": 0,
        "t3": 0, "t4": 0, "t5": 0, "t6": 0
        }
        self.funct3 = {
            "000":"add", "000":"sub", "010":"slt", "101":"srl",
            "110":"or", "111":"and", "010":"lw", "000": "addi",
            "000":"jalr",  "010":"sw",  "000":"beq",  "001":"bne"
        } 
        self.funct7={
             "0000000":"add",  "0100000":"sub",  "0000000":"slt",  "0000000":"srl",  "0000000":"or",  "0000000":"and", "0000001":"mul"
        }
        self.registers = [0] * 32  # 32 general purpose registers
        self.pc = 0                # Program counter
        self.memory = [0] * 1024   # 1KB memory
        self.running = False
        self.verbose = False

    def load_program(self, machine_code):
        """Load machine code into memory"""
        for i, instruction in enumerate(machine_code):
            if i < len(self.memory):
                self.memory[i] = instruction
            else:
                print("Warning: Program too large for memory")
                break

    def fetch(self):
        """Fetch instruction from memory"""
        if self.pc < len(self.memory):
            instruction = self.memory[self.pc]
            self.pc += 1
            return instruction
        return None

    def decode_execute(self, instruction):
        """Decode and execute instruction"""
        # Extract opcode and operands
        opcode = (instruction >> 26) & 0x3F
        rs = (instruction >> 21) & 0x1F
        rt = (instruction >> 16) & 0x1F
        rd = (instruction >> 11) & 0x1F
        shamt = (instruction >> 6) & 0x1F  # Shift amount for SLL
        funct = instruction & 0x3F         # Function code for R-type
        imm = instruction & 0xFFFF         # Immediate value
        imm_sign_extended = imm if imm < 0x8000 else imm - 0x10000  # Sign extension
        target = instruction & 0x03FFFFFF  # Jump target

        if opcode == 0:  # R-Type Instructions
            if funct == 0x20:  # ADD
                self.registers[rd] = self.registers[rs] + self.registers[rt]
                return f"ADD R{rd}, R{rs}, R{rt}"
            elif funct == 0x22:  # SUB
                self.registers[rd] = self.registers[rs] - self.registers[rt]
                return f"SUB R{rd}, R{rs}, R{rt}"
            elif funct == 0x2A:  # SLT
                self.registers[rd] = 1 if self.registers[rs] < self.registers[rt] else 0
                return f"SLT R{rd}, R{rs}, R{rt}"
            elif funct == 0x00:  # SLL
                self.registers[rd] = self.registers[rt] << shamt
                return f"SLL R{rd}, R{rt}, {shamt}"
            elif funct == 0x25:  # OR
                self.registers[rd] = self.registers[rs] | self.registers[rt]
                return f"OR R{rd}, R{rs}, R{rt}"
            elif funct == 0x24:  # AND
                self.registers[rd] = self.registers[rs] & self.registers[rt]
                return f"AND R{rd}, R{rs}, R{rt}"
            elif funct == 0x09:  # JALR (Jump and Link Register)
                self.registers[rt] = self.pc  # Store return address in rt
                self.pc = self.registers[rs]  # Jump to address in rs
                return f"JALR R{rt}, R{rs}"
            else:
                return f"UNKNOWN R-TYPE FUNCTION: {hex(funct)}"

        elif opcode == 0x23:  # LW (Load Word)
            address = self.registers[rs] + imm_sign_extended
            self.registers[rt] = self.memory[address]
            return f"LW R{rt}, {imm_sign_extended}(R{rs})"
        elif opcode == 0x08:  # ADDI (Add Immediate)
            self.registers[rt] = self.registers[rs] + imm_sign_extended
            return f"ADDI R{rt}, R{rs}, {imm_sign_extended}"
        elif opcode == 0x05:  # BNE (Branch if Not Equal)
            if self.registers[rs] != self.registers[rt]:
                self.pc += imm_sign_extended
            return f"BNE R{rs}, R{rt}, #{imm_sign_extended}"
        elif opcode == 0x03:  # JAL (Jump and Link)
            self.registers[31] = self.pc  # Store return address in R31
            self.pc = target
            return f"JAL {hex(target)}"
        else:
            return f"UNKNOWN OPCODE: {hex(opcode)}"

    def run(self, max_cycles=1000):
        """Run the simulation"""
        self.running = True
        cycle = 0
        trace = []

        while self.running and cycle < max_cycles:
            instruction = self.fetch()
            if instruction is None:
                break

            decoded = self.decode_execute(instruction)
            trace.append(f"Cycle {cycle}: PC={self.pc-1} - {decoded}")

            if self.verbose:
                print(trace[-1])
                self.print_registers()

            cycle += 1

        return trace

    def print_registers(self):
        """Print register contents"""
        for i in range(0, 32, 4):
            print(f"R{i:02}-R{i+3:02}:", end=" ")
            for j in range(4):
                print(f"{self.registers[i+j]:08X}", end=" ")
            print()

def main():
    if len(sys.argv) < 3:
        print("Usage: python3 SimpleSimulator.py <input_bin> <output_trace> [output_readable_trace]")
        return

    input_file = sys.argv[1]
    output_file = sys.argv[2]
    readable_file = sys.argv[3] if len(sys.argv) > 3 else None

    try:
        # Read binary file
        with open(input_file, 'r') as f:
            machine_code = [int(line.strip(), 16) for line in f if line.strip()]

        # Initialize and run simulator
        simulator = SimpleSimulator()
        simulator.load_program(machine_code)
        trace = simulator.run()

        # Write trace output
        with open(output_file, 'w') as f:
            f.write("\n".join(trace) + "\n")

        # Write human-readable output if specified
        if readable_file:
            with open(readable_file, 'w') as f:
                f.write("=== Simulation Trace ===\n")
                f.write("\n".join(trace) + "\n")
                f.write("\n=== Final Register State ===\n")
                for i in range(0, 32, 4):
                    f.write(f"R{i:02}-R{i+3:02}: ")
                    for j in range(4):
                        f.write(f"{simulator.registers[i+j]:08X} ")
                    f.write("\n")

    except Exception as e:
        pass

main()
